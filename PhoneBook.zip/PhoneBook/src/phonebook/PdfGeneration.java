package phonebook;

import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.GrayColor;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.FileOutputStream;
import javafx.collections.ObservableList;


public class PdfGeneration {
    public void pdfGeneration(String fileName, ObservableList<Person> data) {
        /**ez a dokumentum maga a fájl, ami ki fog menni pdf-ben
         com.textpdf-ből kell importálni!!!*/        
        Document document = new Document();
        try {
            PdfWriter.getInstance(document,new FileOutputStream(fileName + ".pdf"));
            document.open();
            /**pdf-re egy kép berakása*/
            Image image1= Image.getInstance(getClass().getResource("/logo.jpg"));
            image1.scaleToFit(400,172);
            image1.setAbsolutePosition(135f, 650f);
            document.add(image1);
            /**itt adjuk hozzá a tartalmat, és megadjuk a betűtípust
            document.add(new Paragraph("\n\n\n\n\n\n\n\n\n\n" + teszt, FontFactory.getFont("betutipus",BaseFont.IDENTITY_H,BaseFont.EMBEDDED)));*/
            document.add(new Paragraph("\n\n\n\n\n\n\n\n\n"));
            //Táblázatlétrehozása
            //Oszlopok mennyire legyenek szélesek            
            float[] columnWidths= {2,4,4,6};
            //Létrehozunk egy pdf táblát, amibe átadjuk a szélességeket
            PdfPTable table = new PdfPTable(columnWidths);
            //100%-os széles legyen
            table.setWidthPercentage(100);
            //Csináljon egy header részt
            PdfPCell cell = new PdfPCell(new Phrase("Kontaktlista"));
            /**Háttérszín beállítás, középre állítás, mennyi oszlop széles legyen
            itt ugye 3 oszlopunk lesz, majd átadom a table-nek*/
            cell.setBackgroundColor(GrayColor.GRAYWHITE);
            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            cell.setColspan(4);
            table.addCell(cell);
            
            /*Oszlopmegadás, új szín megadása, hogy meg lehessen különböztetni
            a header-től, középre zárom, majd megadom az oszlo neveket
            */
            table.getDefaultCell().setBackgroundColor(new GrayColor(0.75f));
            table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            table.addCell("Sorszám");
            table.addCell("Vezetéknév");
            table.addCell("Keresztnév");
            table.addCell("Email");
            
            /**Hány darab header sort szeretnék*/
            table.setHeaderRows(1);
            table.getDefaultCell().setBackgroundColor(GrayColor.GRAYWHITE);
            table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            
            /**Feltöltés adatokkal*/
            for(int i = 1; i <= data.size(); i++){
                Person actualPerson = data.get(i-1);
                table.addCell("" + i);
                table.addCell(actualPerson.getLastName());
                table.addCell(actualPerson.getFirstName());
                table.addCell(actualPerson.getEmail());
            }
            
            document.add(table);
            
            /**Hozzáadunk egy aláűírást*/
            Chunk alairas = new Chunk("\n\n Generálva a Telefonkönyv alkalmazás segítségével");
            Paragraph alap = new Paragraph(alairas);
            document.add(alap);
        } catch (Exception e) {
            e.printStackTrace();
        }
        document.close();
        
    }
}
