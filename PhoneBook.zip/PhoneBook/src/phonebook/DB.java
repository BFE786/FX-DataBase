

package phonebook;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;


public class DB {
    final String JDBC_DRIVER="org.apache.derby.jdbc.EmbeddedDriver";
    final String URL="jdbc:derby:sampleDB;create=true";
    //Külső adatbázisszerverhez kella username és a password is:
   // final String USERNAME="";
   // final String PASSWORD="";
    
    //Létrehozzuk a kapcsolatot
    Connection conn= null;
    //Szállító beállítása null-ra
    Statement createStatement = null;
    //Adatbázis létezés vizsgálat null-ra
    DatabaseMetaData dbmd=null;
    
    public DB(){
      //Kapcsolat életre keltése  
        try {
        //Külső adatbázisszerverhez kell a username és a password is:
        // Connection conn= DriverManager.getConnection(URL,USERNAME,PASSWORD);
            conn= DriverManager.getConnection(URL);
            System.out.println("Sikeres");
        } catch (SQLException ex) {
            System.out.println("Baj van a kapcsolattal");
            System.out.println(""+ex);           
        }
        
       //Ha van kapcsolat, akkor itt létrehozunk egy szállítót
        if (conn!=null){
            try {
                createStatement= conn.createStatement();
            } catch (SQLException ex) {
                System.out.println("Baj van a kapcsolattal");
                System.out.println(""+ex);   
            }
        }
        
        //Üres-e az adatbázis?
        try {
            dbmd = conn.getMetaData();
        } catch (SQLException ex) {
           System.out.println("Baj van a kapcsolattal");
        }
        //Resultset: visszaérkeznek az eredmények listaszerűen
        //létezik-e USERS tábla az adatbázisban?
        try{
        ResultSet rs1=dbmd.getTables(null, "APP", "CONTACTS", null);
        //Ha nincs első rekordja sem, akkor létrehozzuk a createStatement. execute-val
        if (!rs1.next())
        {
            createStatement.execute("create table contacts(id INT not null primary key GENERATED ALWAYS AS IDENTITY (START WITH 1,INCREMENT BY 1),lastname varchar(20), firstname varchar(20), email varchar(30))");
            System.out.println("Tábla létrehozva");
        }
        } catch(SQLException ex){
            System.out.println("Baj van a create-al");
            System.out.println(""+ex);
        }  
    }
    public ArrayList<Person> getAllContacts(){
          String sql="select * from CONTACTS";
          ArrayList<Person> users =null;
        try {
            ResultSet rs2= createStatement.executeQuery(sql);
            users = new ArrayList<>();
            while(rs2.next()){
                Person actualPerson=new Person(rs2.getInt("id"), rs2.getString("lastname"),rs2.getString("firstname"),rs2.getString("email"));
                users.add(actualPerson);
            }
        } catch (SQLException ex) {
           System.out.println("Baj van a lekérdezéssel");
            System.out.println(""+ex);
        }
        return users;
    }
    
    public void addContact(Person person){
        try {
            String sql="insert into contacts(lastname,firstname,email) values (?,?,?)";
            PreparedStatement preparedStatement;
            preparedStatement = conn.prepareStatement(sql);
            preparedStatement.setString(1, person.getLastName());
            preparedStatement.setString(2, person.getFirstName());
            preparedStatement.setString(3, person.getEmail());
            preparedStatement.execute();
        }
        catch (SQLException ex) {
            System.out.println("Baj van a contact hozzáadásakor");
            System.out.println(""+ex);
        }
    } 
    public void updateContact(Person person){
        try {
            String sql="update contacts set lastname=?, firstname = ?, email =? where id=?";
            PreparedStatement preparedStatement;
            preparedStatement = conn.prepareStatement(sql);
            preparedStatement.setString(1, person.getLastName());
            preparedStatement.setString(2, person.getFirstName());
            preparedStatement.setString(3, person.getEmail());
            preparedStatement.setInt(4, Integer.parseInt(person.getId()));
            preparedStatement.execute();
        }
        catch (SQLException ex) {
            System.out.println("Baj van a contact hozzáadásakor");
            System.out.println(""+ex);
        }
    } 
    public void removeContact(Person person){
        try {
            String sql="delete from contacts where id=?";
            PreparedStatement preparedStatement;
            preparedStatement = conn.prepareStatement(sql);
            preparedStatement.setInt(1, Integer.parseInt(person.getId()));
            preparedStatement.execute();
        }
        catch (SQLException ex) {
            System.out.println("Baj van a contact törlésekor");
            System.out.println(""+ex);
        }
    } 
}
