package phonebook;

import com.itextpdf.text.Document;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.FileOutputStream;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.SplitPane;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.util.Callback;


public class ViewController implements Initializable {
    
    @FXML
    TableView table;
    @FXML
    TextField inputLastname;
    @FXML
    TextField inputFirstname;
    @FXML
    TextField inputEmail;
    @FXML
    Button addNewContactButton;
    @FXML
    StackPane menuPane;
    @FXML
    Pane contactPane;
    @FXML
    Pane exportPane;
    @FXML
    TextField inputExport;
    @FXML
    Button exportButton;
    @FXML
    AnchorPane anchor;
    @FXML
    SplitPane mainSplit;
    
    DB db = new DB();
    
    private final String MENU_CONTACTS="Kontaktok";
    private final String MENU_LIST="Lista";
    private final String MENU_EXPORT="Exportálás";
    private final String MENU_EXIT="Kilépés";
    
    /**  Létre kell hozni az ObserVableList-et, ami tud tárolni objektumot
     * most pl egy POJO-t , mert adatbázissal dolgozunk az adatbázisból kiolvasott
     * adatok kerülnek be az ObservableList-be, ami a listában van az jelenik
     * meg a Java FX alkalmazás táblájában ezek most itt kamu adatok , mert még 
     * nincs adatbázis
     */      
    private final ObservableList<Person> data = FXCollections.observableArrayList(
       /** new Person("Kis","Laci","valami@gmail.com"),
        new Person("Nagy","Béla","tudod@gmail.com")*/
    );
    
    @FXML
    private void handleButtonAction(ActionEvent event) {
        
    }
    
    /**Új kontakt hozzáadása gomb működése*/
    @FXML
    private void addContact(ActionEvent event){
        /**e-mail ellenőrzésének meg kell előznie a hozzáadást*/
        String email = inputEmail.getText();
        if(email.length() > 3 && email.contains("@") && email.contains(".")){
            Person newPerson= new Person(inputLastname.getText(), inputFirstname.getText(), email);
            data.add(newPerson);
            
        /**adatbázishoz hozzáadjuk*/
            db.addContact(newPerson);
        /**Ne maradjonak abeírt értékek a text-ben, ezért clear-elem*/
            inputLastname.clear();
            inputFirstname.clear();
            inputEmail.clear();
        }
        else{
            alert("Hibás e-mail címet adtál meg!");
        }
    }
    
    /**pdf generálása gombnyomásra*/
    @FXML
    private void exportList(ActionEvent event){
       String fileName = inputExport.getText();
       /**Minden whitespace-t kicsérüln "" erre, és akkor le lehet vizsgálni,
        * hogy nem csak ezek vannak a beírt fájlnévben
        */
       fileName = fileName.replaceAll("\\s+","");
       if(fileName != null && !fileName.equals("")){
            PdfGeneration pdfCreator = new PdfGeneration();
            pdfCreator.pdfGeneration(fileName, data);
        }
       else{
           alert("Adj meg egy fájlnevet!");
       }
    }
    
    
    public void setTableData(){
     TableColumn  lastNameCol= new TableColumn("Vezetéknév");
        /** 100-nál kisebb nem lehet, tehát, ha húzza a felhasználó az
         oszlopot, akkor 100 széles alá nem engedi*/
        lastNameCol.setMinWidth(100);
        /**a mező értékét beállítjuk TextField-nek, hogy tudjunk bele írni*/
        lastNameCol.setCellFactory(TextFieldTableCell.forTableColumn());
        /**Érték ami bekerül, annak a paraméter beállítása 
         PropertyValueFactory olyan objektum, ami két dolgot vesz át, az egyik a POJO,
         a másik pedig milyen típusú értéket veszünk ki a POJO-ból,
         * és aztán megadjuk, hogy milyen néven találja azt az értéket*/
        lastNameCol.setCellValueFactory(new PropertyValueFactory<Person,String>("lastName"));
        
        /**Ha celláknál valami esemény történik és azt akarjuk, hogy szerkezthetőek 
         * legyenek létre kell hozni egy eseménykezelőt(EventHandler)*/
        lastNameCol.setOnEditCommit(
            new EventHandler<TableColumn.CellEditEvent<Person, String>>(){
                @Override
                public void handle(TableColumn.CellEditEvent<Person, String> t){
                       Person actualPerson =(Person) t.getTableView().getItems().get(t.getTablePosition().getRow());
                       actualPerson.setLastName(t.getNewValue());
                
                db.updateContact(actualPerson);
                        }
            }
        );
        
        
        TableColumn  firstNameCol= new TableColumn("Keresztnév");
        firstNameCol.setMinWidth(100);
        firstNameCol.setCellFactory(TextFieldTableCell.forTableColumn());
        firstNameCol.setCellValueFactory(new PropertyValueFactory<Person,String>("firstName"));
        
         firstNameCol.setOnEditCommit(
            new EventHandler<TableColumn.CellEditEvent<Person, String>>(){
                @Override
                public void handle(TableColumn.CellEditEvent<Person, String> t){
                       Person actualPerson =(Person) t.getTableView().getItems().get(t.getTablePosition().getRow());
                       actualPerson.setFirstName(t.getNewValue());
                
                db.updateContact(actualPerson);
                        }
            }
        );
        
        TableColumn  emailCol= new TableColumn("Email");
        emailCol.setMinWidth(200);
        emailCol.setCellFactory(TextFieldTableCell.forTableColumn());
        emailCol.setCellValueFactory(new PropertyValueFactory<Person,String>("email"));
        
         emailCol.setOnEditCommit(
            new EventHandler<TableColumn.CellEditEvent<Person, String>>(){
                @Override
                public void handle(TableColumn.CellEditEvent<Person, String> t){
                       Person actualPerson =(Person) t.getTableView().getItems().get(t.getTablePosition().getRow());
                       actualPerson.setEmail(t.getNewValue());
                
                db.updateContact(actualPerson);
                        }
            }
        );
         
        TableColumn removeCol = new TableColumn("Törlés");
        removeCol.setMinWidth(50);
        Callback<TableColumn<Person, String>, TableCell<Person, String>> cellFactory=
                new Callback<TableColumn<Person, String>, TableCell<Person, String>>(){
                @Override
                public TableCell call(final TableColumn<Person, String> param)
                {
                    final TableCell<Person, String> cell = new TableCell<Person, String>()
                    {
                        final Button btn = new Button("Törlés");
                        
                        @Override
                        public void updateItem (String item, boolean empty)
                        {
                            super.updateItem(item, empty);
                            if(empty)
                            {
                                setGraphic(null);
                                setText(null);
                            }
                            else{
                                btn.setOnAction((ActionEvent event) ->
                                {
                                    Person person = getTableView().getItems().get(getIndex());
                                    data.remove(person);
                                    db.removeContact(person);
                                });
                                setGraphic(btn);
                                setText(null);
                            }
                        }
                    };
                    return cell;
                }
                };
        
        removeCol.setCellFactory(cellFactory);
        
        /** A grafikus táblához hozzáadjuk az oszlopokat- így megjelennek,motmár 
         * névvel ellátva*/
        table.getColumns().addAll(lastNameCol,firstNameCol,emailCol,removeCol);
        
        /**getAllContacts függvény az összes adatbázistartalmat visszaadja,
         ez a select * from-os lekérdezés*/
        data.addAll(db.getAllContacts());
        
        /** Mostmár az adatokat is fel tudjuk tölteni, az ObservableList-ból be
         tudaj a setItems segítségével tölteni*/
        table.setItems(data);
        
     }    
    
    
    private void setMenuData() {
    /** TreeView egy faszerkezetben jelenik meg, TreeItem-mel tudom létrehozni az 
     elsőt*/
        TreeItem<String> treeItemRoot1 = new TreeItem<>("Menü");
        TreeView<String> treeView = new TreeView<>(treeItemRoot1);
        /**ne mutassa a menüt azért kell false-ra tenni*/
        treeView.setShowRoot(false);
        
        TreeItem<String> nodeItemA = new TreeItem<>(MENU_CONTACTS);
        TreeItem<String> nodeItemB = new TreeItem<>(MENU_EXIT);
        /**Nyitva legyen a kontakt menü, azaz látható legyen
         * a programindulásakor a lista, és az exportálás
         */
        nodeItemA.setExpanded(true);
        
        Node contactsNode= new ImageView(new Image(getClass().getResourceAsStream("/kontakt.png")));
        Node exportNode= new ImageView(new Image(getClass().getResourceAsStream("/mentes.png")));
        TreeItem<String> nodeItemA1 = new TreeItem<>(MENU_LIST,contactsNode);
        TreeItem<String> nodeItemA2 = new TreeItem<>(MENU_EXPORT,exportNode);
        
       
        nodeItemA.getChildren().addAll(nodeItemA1,nodeItemA2);
        treeItemRoot1.getChildren().addAll(nodeItemA,nodeItemB);
        
        /**Itt rátesszük a pane-re a menüket*/
        menuPane.getChildren().add(treeView);
        
        /**Listener egy változásra figyel , és abban a pillanatban útjára 
         * indítja az akciót
         */
        treeView.getSelectionModel().selectedItemProperty().addListener(new ChangeListener(){
            public void changed(ObservableValue observable,Object oldValue,Object newValue){
                TreeItem<String> selectedItem =(TreeItem<String>) newValue;
                
                String selectedMenu;
                selectedMenu = selectedItem.getValue();
                System.out.println("Választott menü: " + selectedMenu);
                
                if(null != selectedMenu){
                  switch(selectedMenu){
                        case MENU_CONTACTS:
                            selectedItem.setExpanded(true);
                            break;
                        case MENU_LIST:
                            contactPane.setVisible(false);
                            exportPane.setVisible(true);
                            break;
                        case MENU_EXPORT:
                            contactPane.setVisible(true);
                            exportPane.setVisible(false);
                            break;
                        case MENU_EXIT:
                            /**Bezárni a programot*/
                            System.exit(0);
                            break;
                    }
                }
                
            }
        });
    }
     
    /**PDF generáló program rész, előtte le kell tölteni az itex 5.5 valahanyas
     verzióját, és a Librares-hez hozzá kell adni, mint jar file*/
    
    /**figyelmeztető ablak létrehozása*/
    private void alert(String text){
        mainSplit.setDisable(true);
        mainSplit.setOpacity(0.4);
        
        Label label = new Label(text);
        Button alertButton = new Button("OK");
        VBox vbox = new VBox(label, alertButton);
        vbox.setAlignment(Pos.CENTER);
        
        alertButton.setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent e){
                mainSplit.setDisable(false);
                mainSplit.setOpacity(1);
                vbox.setVisible(false);
            }
        });
        anchor.getChildren().add(vbox);
        anchor.setTopAnchor(vbox, 300.0);
        anchor.setLeftAnchor(vbox, 300.0);
        
    }
    
    /** initialize felelős azért, hogy az első induláskor az összes kód 
     * lefusson, ami a törzsében definiálva van
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
       setTableData();
       setMenuData();
       
       
    }

   

   
}
    
